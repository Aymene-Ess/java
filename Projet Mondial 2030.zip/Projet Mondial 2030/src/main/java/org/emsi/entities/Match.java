package org.emsi.entities;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Entité Match - Représente un match de football
 */
public class Match {
    
    private Integer id;
    private String teamHome;
    private String teamAway;
    private String stadium;
    private String city;
    private Timestamp matchDate;
    private String matchPhase;
    private Set<Zone> zones = new HashSet<>();

    public Match() {}

    public Match(String teamHome, String teamAway, String stadium, String city, Timestamp matchDate) {
        this.teamHome = teamHome;
        this.teamAway = teamAway;
        this.stadium = stadium;
        this.city = city;
        this.matchDate = matchDate;
    }

    // Getters et Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTeamHome() {
        return teamHome;
    }

    public void setTeamHome(String teamHome) {
        this.teamHome = teamHome;
    }

    public String getTeamAway() {
        return teamAway;
    }

    public void setTeamAway(String teamAway) {
        this.teamAway = teamAway;
    }

    public String getStadium() {
        return stadium;
    }

    public void setStadium(String stadium) {
        this.stadium = stadium;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Timestamp getMatchDate() {
        return matchDate;
    }

    public void setMatchDate(Timestamp matchDate) {
        this.matchDate = matchDate;
    }

    public String getMatchPhase() {
        return matchPhase;
    }

    public void setMatchPhase(String matchPhase) {
        this.matchPhase = matchPhase;
    }

    public Set<Zone> getZones() {
        return zones;
    }

    public void setZones(Set<Zone> zones) {
        this.zones = zones;
    }

    public String getDisplayName() {
        return teamHome + " vs " + teamAway;
    }

    @Override
    public String toString() {
        return teamHome + " vs " + teamAway + " - " + stadium + ", " + city;
    }
}
