package org.emsi.entities;

import java.sql.Timestamp;

/**
 * Entité Prediction - Représente un pronostic utilisateur
 */
public class Prediction {

    private Integer id;
    private User user;
    private Match match; // Peut être null si c'est un pronostic sur le vainqueur du tournoi
    private String predictedWinner;
    private String type; // "MATCH" (par match) ou "TOURNAMENT" (vainqueur coupe)
    private Timestamp predictionDate;

    public Prediction() {
    }

    public Prediction(User user, Match match, String predictedWinner, String type) {
        this.user = user;
        this.match = match;
        this.predictedWinner = predictedWinner;
        this.type = type;
        this.predictionDate = new Timestamp(System.currentTimeMillis());
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Match getMatch() {
        return match;
    }

    public void setMatch(Match match) {
        this.match = match;
    }

    public String getPredictedWinner() {
        return predictedWinner;
    }

    public void setPredictedWinner(String predictedWinner) {
        this.predictedWinner = predictedWinner;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Timestamp getPredictionDate() {
        return predictionDate;
    }

    public void setPredictionDate(Timestamp predictionDate) {
        this.predictionDate = predictionDate;
    }
}
