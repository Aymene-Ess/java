package org.emsi.entities;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Equipes")
public class Equipe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nom_pays")
    private String nomPays;

    @Column(name = "drapeau_url")
    private String drapeauUrl;

    @Column(name = "groupe")
    private String groupe;

    @Column(name = "confederation")
    private String confederation;

    @OneToMany(mappedBy = "equipe", fetch = FetchType.EAGER)
    private List<Joueur> joueurs;

    public Equipe() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomPays() {
        return nomPays;
    }

    public void setNomPays(String nomPays) {
        this.nomPays = nomPays;
    }

    public String getDrapeauUrl() {
        return drapeauUrl;
    }

    public void setDrapeauUrl(String drapeauUrl) {
        this.drapeauUrl = drapeauUrl;
    }

    public String getGroupe() {
        return groupe;
    }

    public void setGroupe(String groupe) {
        this.groupe = groupe;
    }

    public String getConfederation() {
        return confederation;
    }

    public void setConfederation(String confederation) {
        this.confederation = confederation;
    }

    public List<Joueur> getJoueurs() {
        return joueurs;
    }

    public void setJoueurs(List<Joueur> joueurs) {
        this.joueurs = joueurs;
    }
}
