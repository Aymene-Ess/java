package org.emsi.dao;

import org.emsi.entities.Ticket;
import org.emsi.entities.User;
import org.emsi.entities.Zone;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.math.BigDecimal;
import java.util.List;

/**
 * DAO pour la gestion des tickets
 */
public class TicketDao {

    private ZoneDao zoneDao = new ZoneDao();

    /**
     * Achète un ticket pour une zone donnée
     */
    public Ticket purchaseTicket(User user, Zone zone) {
        return purchaseTicket(user, zone, null, null);
    }

    /**
     * Achète un ticket pour une zone donnée avec infos invité
     */
    public Ticket purchaseTicket(User user, Zone zone, String guestName, String guestCin) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            // Vérifier la disponibilité
            Zone freshZone = session.get(Zone.class, zone.getId());
            if (freshZone == null || !freshZone.hasAvailableSeats()) {
                transaction.rollback();
                return null;
            }

            // Décrémenter les places
            freshZone.decrementSeats();
            session.update(freshZone);

            // Créer le ticket
            Ticket ticket;
            if (guestName != null && guestCin != null) {
                ticket = new Ticket(user, freshZone, guestName, guestCin);
            } else {
                ticket = new Ticket(user, freshZone);
            }
            session.save(ticket);

            transaction.commit();
            return ticket;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    /**
     * Récupère un ticket par son ID
     */
    public Ticket findById(Integer id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Ticket.class, id);
        }
    }

    /**
     * Récupère un ticket par son UUID QR Code
     */
    public Ticket findByQrCode(String uuidQrcode) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Ticket> query = session.createQuery(
                    "FROM Ticket WHERE uuidQrcode = :uuid", Ticket.class);
            query.setParameter("uuid", uuidQrcode);
            return query.uniqueResult();
        }
    }

    /**
     * Liste les tickets d'un utilisateur
     */
    public List<Ticket> findByUser(Integer userId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Ticket> query = session.createQuery(
                    "FROM Ticket WHERE user.id = :userId ORDER BY purchaseDate DESC",
                    Ticket.class);
            query.setParameter("userId", userId);
            return query.list();
        }
    }

    /**
     * Liste les tickets actifs d'un utilisateur
     */
    public List<Ticket> findActiveByUser(Integer userId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Ticket> query = session.createQuery(
                    "FROM Ticket WHERE user.id = :userId AND status = 'ACTIF' ORDER BY purchaseDate DESC",
                    Ticket.class);
            query.setParameter("userId", userId);
            return query.list();
        }
    }

    /**
     * Liste les tickets en revente (marché secondaire)
     */
    public List<Ticket> findForResale() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Ticket> query = session.createQuery(
                    "FROM Ticket WHERE status = 'EN_REVENTE' ORDER BY resalePrice",
                    Ticket.class);
            return query.list();
        }
    }

    /**
     * Met un ticket en revente
     */
    public void putForResale(Integer ticketId, BigDecimal resalePrice) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            Ticket ticket = session.get(Ticket.class, ticketId);
            if (ticket != null && ticket.isActive()) {
                ticket.putForResale(resalePrice);
                session.update(ticket);
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    /**
     * Annule la mise en revente d'un ticket
     */
    public void cancelResale(Integer ticketId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            Ticket ticket = session.get(Ticket.class, ticketId);
            if (ticket != null && ticket.isForResale()) {
                ticket.cancelResale();
                session.update(ticket);
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    /**
     * Achète un ticket sur le marché secondaire
     */
    public Ticket buyResaleTicket(Integer ticketId, User newOwner) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            Ticket ticket = session.get(Ticket.class, ticketId);
            if (ticket != null && ticket.isForResale()) {
                // Transférer le ticket au nouvel acheteur
                ticket.setUser(newOwner);
                ticket.setStatus("ACTIF");
                ticket.setResalePrice(null);
                session.update(ticket);

                transaction.commit();
                return ticket;
            }

            transaction.rollback();
            return null;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    /**
     * Marque un ticket comme utilisé
     */
    public void markAsUsed(Integer ticketId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            Ticket ticket = session.get(Ticket.class, ticketId);
            if (ticket != null) {
                ticket.markAsUsed();
                session.update(ticket);
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    /**
     * Liste tous les tickets
     */
    public List<Ticket> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Ticket ORDER BY purchaseDate DESC", Ticket.class).list();
        }
    }

    /**
     * Supprime un ticket et libère la place
     */
    public void delete(Ticket ticketEntity) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            Ticket ticket = session.get(Ticket.class, ticketEntity.getId());
            if (ticket != null) {
                // Return seat to pool
                Zone zone = ticket.getZone();
                if (zone != null) {
                    zone.setAvailableSeats(zone.getAvailableSeats() + 1);
                    session.update(zone);
                }
                session.delete(ticket);
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null)
                transaction.rollback();
            e.printStackTrace();
        }
    }
}
