package org.emsi.dao;

import org.emsi.entities.Zone;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

/**
 * DAO pour la gestion des zones de stade
 */
public class ZoneDao {

    /**
     * Récupère une zone par son ID
     */
    public Zone findById(Integer id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Zone.class, id);
        }
    }

    /**
     * Liste les zones d'un match donné
     */
    public List<Zone> findByMatch(Integer matchId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Zone> query = session.createQuery(
                    "FROM Zone WHERE match.id = :matchId ORDER BY categoryName",
                    Zone.class);
            query.setParameter("matchId", matchId);
            return query.list();
        }
    }

    /**
     * Liste les zones disponibles (avec places restantes) pour un match
     */
    public List<Zone> findAvailableByMatch(Integer matchId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Zone> query = session.createQuery(
                    "FROM Zone WHERE match.id = :matchId AND availableSeats > 0 ORDER BY categoryName",
                    Zone.class);
            query.setParameter("matchId", matchId);
            return query.list();
        }
    }

    /**
     * Décrémente le nombre de places disponibles d'une zone
     */
    public boolean decrementSeats(Integer zoneId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            Zone zone = session.get(Zone.class, zoneId);
            if (zone != null && zone.hasAvailableSeats()) {
                zone.decrementSeats();
                session.update(zone);
                transaction.commit();
                return true;
            }

            if (transaction != null) {
                transaction.rollback();
            }
            return false;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    /**
     * Incrémente le nombre de places disponibles d'une zone (lors d'une annulation)
     */
    public void incrementSeats(Integer zoneId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            Zone zone = session.get(Zone.class, zoneId);
            if (zone != null) {
                zone.incrementSeats();
                session.update(zone);
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    /**
     * Sauvegarde une nouvelle zone
     */
    public void save(Zone zone) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(zone);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    /**
     * Met à jour une zone
     */
    public void update(Zone zone) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(zone);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }
}
