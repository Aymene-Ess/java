package org.emsi;

import org.emsi.dao.HibernateUtil;
import org.emsi.dao.UserDao;
import org.emsi.entities.User;
import org.hibernate.Session;

import java.util.List;

public class DbTest {
    public static void main(String[] args) {
        System.out.println("=== STARTING DB TEST ===");
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            System.out.println("Hibernate Session Opened Successfully!");

            UserDao userDao = new UserDao();
            System.out.println("Checking for admin user...");
            if (userDao.usernameExists("admin")) {
                System.out.println("User 'admin' FOUND.");
                User u = userDao.authenticate("admin", "admin123");
                if (u != null) {
                    System.out.println("Authentication for admin/admin123 SUCCEEDED.");
                } else {
                    System.out.println("Authentication for admin/admin123 FAILED (Wrong password?).");
                }
            } else {
                System.out.println("User 'admin' NOT FOUND.");
            }

            session.close();
        } catch (Throwable t) {
            System.err.println("DB TEST FAILED WITH EXCEPTION:");
            t.printStackTrace();
        }
        System.out.println("=== END DB TEST ===");
        System.exit(0);
    }
}
