package org.emsi.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestDbConnection {
    public static void main(String[] args) {
        String jdbcUrl = "jdbc:mysql://localhost:3307/mondial2030?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
        String user = "mondial_user";
        String pass = "mondial_pass";

        System.out.println("Testing connection to: " + jdbcUrl);

        try (Connection conn = DriverManager.getConnection(jdbcUrl, user, pass)) {
            String msg = "CONNECTION SUCCESSFUL!";
            System.out.println(msg);
            java.nio.file.Files.write(java.nio.file.Paths.get("db_test.log"), msg.getBytes());
        } catch (Exception e) {
            String msg = "CONNECTION FAILED: " + e.getMessage();
            System.err.println(msg);
            e.printStackTrace();
            try {
                java.io.PrintWriter pw = new java.io.PrintWriter("db_test.log");
                e.printStackTrace(pw);
                pw.close();
            } catch (Exception ex) {
            }
        }
    }
}
