package org.emsi.util;

import org.emsi.dao.UserDao;
import org.emsi.entities.User;
import org.emsi.dao.HibernateUtil;
import java.util.List;

public class ListUsers {
    public static void main(String[] args) {
        System.out.println("=== LISTE DES UTILISATEURS ===");
        try {
            // Using direct HQL via HibernateUtil as UserDao might not have findAll exposed
            // publicly cleanly or we want to be sure
            // Actually UserDao usually has methods. Let's try raw session to be safe and
            // simple.

            try (org.hibernate.Session session = HibernateUtil.getSessionFactory().openSession()) {
                List<User> users = session.createQuery("FROM User", User.class).list();
                if (users.isEmpty()) {
                    System.out.println("Aucun utilisateur trouvé dans la base de données.");
                } else {
                    for (User u : users) {
                        System.out.println("ID: " + u.getId() + " | Username: " + u.getUsername() + " | Role: "
                                + u.getRole() + " | Email: " + u.getEmail());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            HibernateUtil.shutdown();
        }
        System.out.println("==============================");
    }
}
