package org.emsi.controllers;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.emsi.App;
import org.emsi.dao.MatchDao;
import org.emsi.entities.Match;
import org.emsi.entities.Zone;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Contrôleur pour la liste des matchs
 */
public class MatchesController {

    @FXML
    private VBox matchesContainer;
    @FXML
    private TextField searchField;

    private final MatchDao matchDao = new MatchDao();
    private List<Match> allMatches;

    @FXML
    public void initialize() {
        loadMatches();

        // Recherche en temps réel
        searchField.textProperty().addListener((obs, oldVal, newVal) -> filterMatches(newVal));
    }

    private void loadMatches() {
        try {
            allMatches = matchDao.findAll();
            displayMatches(allMatches);
        } catch (Exception e) {
            matchesContainer.getChildren().clear();
            Label error = new Label("❌ Erreur: Impossible de charger les matchs. Vérifiez Docker.");
            error.getStyleClass().add("error-label");
            matchesContainer.getChildren().add(error);
        }
    }

    private void displayMatches(List<Match> matches) {
        matchesContainer.getChildren().clear();
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE dd MMMM yyyy à HH:mm");

        if (matches.isEmpty()) {
            Label noMatch = new Label("Aucun match trouvé");
            noMatch.getStyleClass().add("no-results");
            matchesContainer.getChildren().add(noMatch);
            return;
        }

        for (Match match : matches) {
            StackPane card = createMatchRow(match, sdf);
            matchesContainer.getChildren().add(card);
        }
    }

    private StackPane createMatchRow(Match match, SimpleDateFormat sdf) {
        // 1. Root Card with Diagonal Gradient Background
        StackPane card = new StackPane();
        card.getStyleClass().add("card-match-luxury");
        card.setPrefHeight(180);
        card.setMinHeight(180);

        // 2. Main Layout Container (HBox)
        HBox container = new HBox(0); // No spacing, we control positions
        container.setAlignment(Pos.CENTER_LEFT);
        container.setPadding(new javafx.geometry.Insets(10, 30, 10, 30));

        // --- LEFT SECTION (Ruby Red Area) ---
        VBox leftSection = new VBox(8);
        leftSection.setPrefWidth(350);
        leftSection.setMaxWidth(350);
        leftSection.setAlignment(Pos.CENTER_LEFT);

        // Teams
        Label lblHome = new Label(match.getTeamHome());
        lblHome.setStyle(
                "-fx-text-fill: #D4AF37; -fx-font-size: 24px; -fx-font-weight: 900; -fx-effect: dropshadow(gaussian, black, 2, 0, 1, 1);");

        Label lblVs = new Label("VS");
        lblVs.setStyle("-fx-text-fill: rgba(255,255,255,0.8); -fx-font-size: 14px; -fx-font-weight: bold;");

        Label lblAway = new Label(match.getTeamAway());
        lblAway.setStyle(
                "-fx-text-fill: #D4AF37; -fx-font-size: 24px; -fx-font-weight: 900; -fx-effect: dropshadow(gaussian, black, 2, 0, 1, 1);");

        // Details (Stadium & Date)
        HBox detailsBox = new HBox(10);
        detailsBox.setAlignment(Pos.CENTER_LEFT);

        Label lblStadium = new Label("📍 " + match.getCity() + " (" + match.getStadium() + ")");
        lblStadium.setStyle("-fx-text-fill: #E0E0E0; -fx-font-size: 12px;");

        Label lblDate = new Label("📅 " + sdf.format(match.getMatchDate()));
        lblDate.setStyle("-fx-text-fill: #E0E0E0; -fx-font-size: 12px;");

        VBox metaBox = new VBox(3);
        metaBox.getChildren().addAll(lblStadium, lblDate);

        leftSection.getChildren().addAll(lblHome, lblVs, lblAway, metaBox);

        // --- CENTER SECTION (Emerald Green Area) ---
        // Trophée & Prix
        VBox centerSection = new VBox(5);
        HBox.setHgrow(centerSection, Priority.ALWAYS); // Takes available space
        centerSection.setAlignment(Pos.CENTER);

        // Trophy Header
        Label lblTrophy = new Label("🏆 Coupe du Monde Maroc 2030 🏆");
        lblTrophy.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");

        // Image Trophée (Jellaba/Mascot)
        javafx.scene.image.ImageView imgTrophy = new javafx.scene.image.ImageView();
        try {
            imgTrophy.setImage(new javafx.scene.image.Image(
                    getClass().getResourceAsStream("/org/emsi/images/mascot_jallaba.png")));
        } catch (Exception e) {
            /* Ignore */ }
        imgTrophy.setFitHeight(80);
        imgTrophy.setPreserveRatio(true);
        imgTrophy.setStyle("-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.4), 10, 0, 0, 5);");

        // Prices Badges
        HBox pricesBox = new HBox(15);
        pricesBox.setAlignment(Pos.CENTER);

        // Generate Dummy Prices based on Zone logic (or static for demo if data
        // missing)
        // We iterate zones but limit to 3 for visuals
        int pCount = 0;
        for (Zone zone : match.getZones()) {
            if (pCount >= 3)
                break;
            VBox badge = createPriceBadge(zone.getCategoryName(), zone.getPrice() + " MAD");
            pricesBox.getChildren().add(badge);
            pCount++;
        }
        // Fallback if no zones
        if (pCount == 0) {
            pricesBox.getChildren().add(createPriceBadge("CAT 1", "2000 MAD"));
            pricesBox.getChildren().add(createPriceBadge("CAT 2", "800 MAD"));
        }

        centerSection.getChildren().addAll(lblTrophy, imgTrophy, pricesBox);

        // --- RIGHT SECTION (Action) ---
        VBox rightSection = new VBox();
        rightSection.setMinWidth(180);
        rightSection.setAlignment(Pos.CENTER_RIGHT);

        Button btnBuy = new Button("ACHETER");
        btnBuy.getStyleClass().add("btn-buy-gold-relief");
        btnBuy.setPrefWidth(160);
        btnBuy.setPrefHeight(50);
        btnBuy.setOnAction(e -> navigateToPurchase(match.getId()));

        rightSection.getChildren().add(btnBuy);

        // Assemble
        container.getChildren().addAll(leftSection, centerSection, rightSection);
        card.getChildren().add(container);

        return card;
    }

    private VBox createPriceBadge(String title, String price) {
        VBox badge = new VBox(2);
        badge.setAlignment(Pos.CENTER);
        badge.setStyle(
                "-fx-border-color: #D4AF37; -fx-border-width: 1; -fx-background-color: rgba(0, 50, 0, 0.6); -fx-padding: 3 8; -fx-border-radius: 4;");

        Label lblTitle = new Label(title);
        lblTitle.setStyle("-fx-text-fill: #D4AF37; -fx-font-weight: bold; -fx-font-size: 10px;");

        Label lblPrice = new Label(price);
        lblPrice.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 11px;");

        badge.getChildren().addAll(lblTitle, lblPrice);
        return badge;
    }

    private void filterMatches(String query) {
        if (query == null || query.isEmpty()) {
            displayMatches(allMatches);
            return;
        }

        String lowerQuery = query.toLowerCase();
        List<Match> filtered = allMatches.stream()
                .filter(m -> m.getTeamHome().toLowerCase().contains(lowerQuery) ||
                        m.getTeamAway().toLowerCase().contains(lowerQuery) ||
                        m.getStadium().toLowerCase().contains(lowerQuery) ||
                        m.getCity().toLowerCase().contains(lowerQuery))
                .toList();

        displayMatches(filtered);
    }

    private void navigateToPurchase(Integer matchId) {
        try {
            PurchaseController.setSelectedMatchId(matchId);
            App.setRoot("views/purchase");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("views/home");
    }
}
