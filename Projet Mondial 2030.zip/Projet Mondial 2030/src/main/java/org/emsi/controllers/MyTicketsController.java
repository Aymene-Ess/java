package org.emsi.controllers;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import org.emsi.App;
import org.emsi.dao.TicketDao;
import org.emsi.entities.Ticket;
import org.emsi.util.QRCodeGenerator;
import org.emsi.util.SessionManager;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;

/**
 * Contrôleur pour la page "Mes Tickets"
 */
public class MyTicketsController {

    @FXML
    private VBox ticketsContainer;
    @FXML
    private Label ticketCountLabel;
    @FXML
    private VBox ticketDetailModal;
    @FXML
    private ImageView qrCodeImage;
    @FXML
    private Label qrCodeUuid;
    @FXML
    private Label modalMatchLabel;
    @FXML
    private Label modalZoneLabel;
    @FXML
    private Label modalStadiumLabel;
    @FXML
    private Label modalDateLabel;
    @FXML
    private Button resaleBtn;
    @FXML
    private Button cancelResaleBtn;

    private final TicketDao ticketDao = new TicketDao();
    private Ticket selectedTicket;

    @FXML
    public void initialize() {
        loadTickets();
    }

    private void loadTickets() {
        ticketsContainer.getChildren().clear();

        try {
            Integer userId = SessionManager.getInstance().getCurrentUserId();
            List<Ticket> tickets = ticketDao.findByUser(userId);

            ticketCountLabel.setText(tickets.size() + " ticket(s)");

            if (tickets.isEmpty()) {
                VBox emptyState = new VBox(25);
                emptyState.setAlignment(Pos.CENTER);
                emptyState.getStyleClass().add("empty-state-container");

                // Icône Ticket Minimaliste
                Label icon = new Label("🎫");
                icon.getStyleClass().add("empty-icon");

                // Message
                Label message = new Label("Vous n'avez pas encore de tickets");
                message.getStyleClass().add("empty-message-label");

                // Bouton Action (Lingot d'Or)
                Button buyBtn = new Button("ACHETER");
                buyBtn.getStyleClass().add("btn-gold-ingot");
                buyBtn.setOnAction(e -> {
                    try {
                        App.setRoot("views/matches");
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                });

                emptyState.getChildren().addAll(icon, message, buyBtn);
                ticketsContainer.getChildren().add(emptyState);
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

            for (Ticket ticket : tickets) {
                HBox card = createTicketCard(ticket, sdf);
                ticketsContainer.getChildren().add(card);
            }
        } catch (Exception e) {
            Label error = new Label("❌ Erreur lors du chargement des tickets");
            error.getStyleClass().add("error-label");
            ticketsContainer.getChildren().add(error);
            e.printStackTrace();
        }
    }

    private HBox createTicketCard(Ticket ticket, SimpleDateFormat sdf) {
        // Conteneur principal (La carte entière)
        HBox card = new HBox(0);
        card.getStyleClass().add("ticket-card-luxury");
        card.setAlignment(Pos.CENTER_LEFT);

        // --- PARTIE GAUCHE (INFO MATCH - Fond Blanc) ---
        VBox leftPart = new VBox(10);
        leftPart.getStyleClass().add("ticket-left-panel");
        leftPart.setMinWidth(500);
        HBox.setHgrow(leftPart, Priority.ALWAYS);

        // En-tête du ticket (Match)
        Label matchLabel = new Label(ticket.getZone().getMatch().getDisplayName());
        matchLabel.getStyleClass().add("ticket-match-title");

        // Info Zone & Prix
        HBox zoneInfo = new HBox(15);
        Label zoneLabel = new Label(
                "ZONE " + ticket.getZone().getCategoryName() + " " + ticket.getZone().getPrice() + " MAD");
        zoneLabel.getStyleClass().add("ticket-zone-price");
        zoneInfo.getChildren().add(zoneLabel);

        // Détails (Lieu, Date) - Pins et icones simulés par texte pour l'instant
        VBox details = new VBox(8);

        // Lieu
        HBox venueRow = new HBox(10);
        venueRow.setAlignment(Pos.CENTER_LEFT);
        Label pinIcon = new Label("📍"); // Pin icon
        Label stadiumLabel = new Label(ticket.getZone().getMatch().getStadium());
        stadiumLabel.getStyleClass().add("ticket-info-row");
        venueRow.getChildren().addAll(pinIcon, stadiumLabel);

        // Date
        HBox dateRow = new HBox(10);
        dateRow.setAlignment(Pos.CENTER_LEFT);
        Label calendarIcon = new Label("📅"); // Calendar icon
        Label dateLabel = new Label(sdf.format(ticket.getZone().getMatch().getMatchDate()));
        dateLabel.getStyleClass().add("ticket-info-row");
        dateRow.getChildren().addAll(calendarIcon, dateLabel);

        details.getChildren().addAll(venueRow, dateRow);

        leftPart.getChildren().addAll(matchLabel, zoneInfo, details);

        // --- PARTIE DROITE (QR CODE - Fond Bleu Nuit) ---
        VBox rightPart = new VBox(15);
        rightPart.getStyleClass().add("ticket-right-panel");
        rightPart.setMinWidth(200);
        rightPart.setMaxWidth(200);
        rightPart.setAlignment(Pos.CENTER);

        // Grand QR Code (Blanc sur fond bleu)
        ImageView qrPreview = new ImageView(QRCodeGenerator.generateQRCode(ticket.getUuidQrcode()));
        qrPreview.setFitWidth(100);
        qrPreview.setFitHeight(100);

        // Container pour le QR code (bordure blanche/glow)
        StackPane qrContainer = new StackPane(qrPreview);
        qrContainer.getStyleClass().add("ticket-qr-code");

        // Code UUID tronqué
        Label uuidPreview = new Label(ticket.getUuidQrcode().substring(0, 8) + "...");
        uuidPreview.setStyle("-fx-text-fill: white; -fx-font-family: 'Consolas'; -fx-font-size: 12px;");

        // Bouton Détails (Bleu clair contour)
        Button actionBtn = new Button("Détails");
        actionBtn.getStyleClass().add("btn-details-luxury");
        actionBtn.setOnAction(e -> showTicketDetail(ticket));

        rightPart.getChildren().addAll(qrContainer, uuidPreview, actionBtn);

        // Assemblage
        card.getChildren().addAll(leftPart, rightPart);
        return card;
    }

    private String getStatusIcon(String status) {
        return switch (status) {
            case "ACTIF" -> "✅";
            case "EN_REVENTE" -> "🔄";
            case "VENDU" -> "💸";
            case "UTILISE" -> "✔️";
            default -> "🎫";
        };
    }

    private void showTicketDetail(Ticket ticket) {
        selectedTicket = ticket;

        // Générer le QR Code
        Image qrCode = QRCodeGenerator.generateQRCode(ticket.getUuidQrcode());
        qrCodeImage.setImage(qrCode);
        qrCodeUuid.setText(ticket.getUuidQrcode());

        SimpleDateFormat sdf = new SimpleDateFormat("EEEE dd MMMM yyyy à HH:mm");

        modalMatchLabel.setText(ticket.getZone().getMatch().getDisplayName());
        modalZoneLabel
                .setText("ZONE " + ticket.getZone().getCategoryName() + " " + ticket.getZone().getPrice() + " MAD");
        modalStadiumLabel.setText(ticket.getZone().getMatch().getStadium());
        modalDateLabel.setText(sdf.format(ticket.getZone().getMatch().getMatchDate()));

        // Afficher/masquer les boutons selon le statut
        boolean isActive = ticket.isActive();
        boolean isForResale = ticket.isForResale();

        resaleBtn.setVisible(isActive);
        resaleBtn.setManaged(isActive);
        cancelResaleBtn.setVisible(isForResale);
        cancelResaleBtn.setManaged(isForResale);

        // Afficher le modal
        ticketDetailModal.setVisible(true);
        ticketDetailModal.setManaged(true);
    }

    @FXML
    private void closeModal() {
        ticketDetailModal.setVisible(false);
        ticketDetailModal.setManaged(false);
        selectedTicket = null;
    }

    @FXML
    private void putForResale() {
        if (selectedTicket == null)
            return;

        // Demander le prix de revente
        TextInputDialog dialog = new TextInputDialog(selectedTicket.getZone().getPrice().toString());
        dialog.setTitle("Mettre en revente");
        dialog.setHeaderText("Prix de revente");
        dialog.setContentText("Entrez le prix de revente (MAD):");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(priceStr -> {
            try {
                BigDecimal price = new BigDecimal(priceStr);
                ticketDao.putForResale(selectedTicket.getId(), price);
                closeModal();
                loadTickets();
            } catch (NumberFormatException e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erreur");
                alert.setContentText("Veuillez entrer un prix valide");
                alert.showAndWait();
            }
        });
    }

    @FXML
    private void cancelResale() {
        if (selectedTicket == null)
            return;

        ticketDao.cancelResale(selectedTicket.getId());
        closeModal();
        loadTickets();
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("views/home");
    }
}
