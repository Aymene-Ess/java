package org.emsi.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import org.emsi.App;
import org.emsi.dao.EquipeDao;
import org.emsi.dao.JoueurDao;
import org.emsi.dao.MatchDao;
import org.emsi.dao.StadeDao;
import org.emsi.entities.Equipe;
import org.emsi.entities.Joueur;
import org.emsi.entities.Match;
import org.emsi.entities.Stade;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

public class MatchDetailsController {

    private static Integer selectedMatchId;

    @FXML
    private Label matchTitleLabel;
    @FXML
    private Label dateLabel;
    @FXML
    private Label stadiumLabel;
    @FXML
    private Label cityLabel;
    @FXML
    private Label distanceLabel;

    @FXML
    private Label homeTeamLabel;
    @FXML
    private ListView<String> homeTeamList;
    @FXML
    private Label awayTeamLabel;
    @FXML
    private ListView<String> awayTeamList;

    private final MatchDao matchDao = new MatchDao();
    private final StadeDao stadeDao = new StadeDao();
    private final EquipeDao equipeDao = new EquipeDao();
    private final JoueurDao joueurDao = new JoueurDao();

    public static void setMatchId(Integer matchId) {
        selectedMatchId = matchId;
    }

    @FXML
    public void initialize() {
        if (selectedMatchId == null)
            return;

        Match match = matchDao.findById(selectedMatchId);
        if (match != null) {
            matchTitleLabel.setText(match.getTeamHome() + " vs " + match.getTeamAway());
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy - HH:mm");
            dateLabel.setText(sdf.format(match.getMatchDate()));

            // Stadium Details
            Stade stade = stadeDao.findByName(match.getStadium());
            stadiumLabel.setText("📍 " + match.getStadium());
            cityLabel.setText(match.getCity());

            if (stade != null) {
                distanceLabel.setText("Distance centre-ville : " + stade.getDistanceCentreVilleKm() + " km");
            } else {
                distanceLabel.setText("Distance : N/A");
            }

            // Teams & Rosters
            loadTeamRoster(match.getTeamHome(), homeTeamLabel, homeTeamList);
            loadTeamRoster(match.getTeamAway(), awayTeamLabel, awayTeamList);
        }
    }

    private void loadTeamRoster(String teamName, Label label, ListView<String> listView) {
        label.setText("Equipe " + teamName);
        Equipe equipe = equipeDao.findByName(teamName);
        if (equipe != null) {
            List<Joueur> joueurs = joueurDao.findByEquipe(equipe.getId());
            for (Joueur j : joueurs) {
                listView.getItems().add(j.getNumeroMaillot() + ". " + j.getNomComplet() + " (" + j.getPosition() + ")");
            }
        } else {
            listView.getItems().add("Composition non disponible");
        }
    }

    @FXML
    private void handleBack() throws IOException {
        App.setRoot("views/home");
    }

    @FXML
    private void handleBuyTicket() throws IOException {
        PurchaseController.setSelectedMatchId(selectedMatchId);
        App.setRoot("views/purchase");
    }
}
