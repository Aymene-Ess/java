package org.emsi.controllers;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.emsi.App;
import org.emsi.dao.TicketDao;
import org.emsi.entities.Ticket;
import org.emsi.entities.User;
import org.emsi.util.SessionManager;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Contrôleur pour le marché secondaire (revente)
 */
public class ResaleController {

    @FXML
    private HBox resaleContainer; // Changed to HBox for horizontal scrolling
    @FXML
    private Label resaleCountLabel;

    private final TicketDao ticketDao = new TicketDao();

    @FXML
    public void initialize() {
        loadResaleTickets();
    }

    private void loadResaleTickets() {
        resaleContainer.getChildren().clear();

        try {
            List<Ticket> tickets = ticketDao.findForResale(); // Assuming this fetches user's sale tickets or logic
                                                              // needs adjustment to match "Mes Ventes" (usually implies
                                                              // current user's sales)
            // Wait, "Revendre" page usually implies "Marketplace" to BUY, but the prompt
            // says "Mes ventes" (My Sales).
            // If it's "Mes ventes", we should filter by current user.
            // If it's "Marketplace", we show all.
            // The prompt "visualiser l'ensemble des billets qu'il a mis en revente" -> MY
            // SALES.
            // So we need to filter by current user.

            User currentUser = SessionManager.getInstance().getCurrentUser();
            // TODO: Ensure ticketDao.findForResale() returns what we need, or filter here.
            // For now, assuming findForResale returns ALL, so we might check ownership.
            // Actually, if it is "Mes Ventes", we likely want
            // `ticketDao.findByUserAndStatus(user, RESALE_PENDING)`.
            // Let's stick to the previous pattern but check ID match.

            long mySalesCount = tickets.stream()
                    .filter(t -> t.getUser().getId().equals(currentUser.getId()))
                    .count();

            resaleCountLabel.setText(mySalesCount + " ticket(s) disponibles");

            if (mySalesCount == 0) {
                // Empty state handling
                Label empty = new Label("Aucune vente en cours.");
                empty.setStyle("-fx-text-fill: #333; -fx-font-size: 16px;");
                resaleContainer.getChildren().add(empty);
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

            for (Ticket ticket : tickets) {
                // Show ONLY my tickets
                if (ticket.getUser().getId().equals(currentUser.getId())) {
                    VBox card = createResaleCard(ticket, sdf);
                    resaleContainer.getChildren().add(card);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private VBox createResaleCard(Ticket ticket, SimpleDateFormat sdf) {
        // Vertical Card Style
        VBox card = new VBox(10);
        card.getStyleClass().add("sale-card-gold");
        card.setAlignment(Pos.TOP_LEFT);

        // Header: Title + ... Button
        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);

        Label titleLabel = new Label("Ticket: Match"); // Simplified for design
        titleLabel.getStyleClass().add("sale-card-gold-title");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button menuBtn = new Button("...");
        menuBtn.getStyleClass().add("btn-action-circle");

        header.getChildren().addAll(titleLabel, spacer, menuBtn);

        // Price & Zone
        Label detailsLabel = new Label(ticket.getResalePrice() + " MAD - Zone: " + ticket.getZone().getCategoryName());
        detailsLabel.getStyleClass().add("sale-card-gold-details");
        detailsLabel.setWrapText(true);

        // Date
        HBox dateBox = new HBox(5);
        dateBox.setAlignment(Pos.CENTER_LEFT);
        Label dateIcon = new Label("📅"); // Or use FontIcon if available
        Label dateText = new Label(sdf.format(ticket.getZone().getMatch().getMatchDate()));
        dateText.getStyleClass().add("sale-card-gold-date");
        dateBox.getChildren().addAll(dateIcon, dateText);

        card.getChildren().addAll(header, detailsLabel, dateBox);
        return card;
    }

    @FXML
    private void handleStartSell() {
        // Not used in this view anymore, but good to keep if referenced by other things
        // or future use
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText("Mise en vente bientôt disponible");
        alert.setContentText("Cette fonctionnalité sera implémentée prochainement.");
        alert.showAndWait();
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("views/home");
    }
}
