package org.emsi.controllers;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.emsi.App;
import org.emsi.dao.MatchDao;
import org.emsi.dao.TicketDao;
import org.emsi.dao.PredictionDao;
import org.emsi.entities.Match;
import org.emsi.entities.Prediction;
import org.emsi.entities.User;
import org.emsi.util.SessionManager;
import javafx.collections.FXCollections;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Contrôleur pour la page d'accueil
 */
public class HomeController {

    @FXML
    private Label welcomeLabel;
    @FXML
    private Label userLabel;
    @FXML
    private Label ticketCountLabel;
    @FXML
    private HBox matchesPreviewContainer;
    @FXML
    private VBox contentArea;

    @FXML
    private ComboBox<String> winnerPredictionCombo;
    @FXML
    private Label predictionStatusLabel;

    private final MatchDao matchDao = new MatchDao();
    private final TicketDao ticketDao = new TicketDao();
    private final PredictionDao predictionDao = new PredictionDao();

    @FXML
    public void initialize() {
        User user = SessionManager.getInstance().getCurrentUser();

        if (user != null) {
            welcomeLabel.setText("Bienvenue, " + user.getUsername() + " ! 👋");
            userLabel.setText(user.getUsername()); // Icon handled by info box

            // Compter les tickets de l'utilisateur
            try {
                int ticketCount = ticketDao.findByUser(user.getId()).size();
                ticketCountLabel.setText(String.valueOf(ticketCount));
            } catch (Exception e) {
                ticketCountLabel.setText("0");
            }
        }

        // Charger les pays pour le pronostic
        if (winnerPredictionCombo != null) {
            winnerPredictionCombo.setItems(FXCollections.observableArrayList(
                    "Maroc 🇲🇦", "Espagne 🇪🇸", "Portugal 🇵🇹",
                    "France 🇫🇷", "Brésil 🇧🇷", "Argentine 🇦🇷",
                    "Allemagne 🇩🇪", "Angleterre 🏴󠁧󠁢󠁥󠁮󠁧󠁿"));
        }

        loadMatchesPreview();
    }

    @FXML
    private void handleTournamentPrediction() {
        String selected = winnerPredictionCombo.getValue();
        if (selected == null) {
            predictionStatusLabel.setText("Veuillez sélectionner un pays !");
            predictionStatusLabel.setStyle("-fx-text-fill: red;");
            predictionStatusLabel.setVisible(true);
            return;
        }

        try {
            User user = SessionManager.getInstance().getCurrentUser();
            Prediction prediction = new Prediction(user, null, selected, "TOURNAMENT");
            predictionDao.save(prediction);

            predictionStatusLabel.setText("✅ Pronostic enregistré ! Bonne chance !");
            predictionStatusLabel.setStyle("-fx-text-fill: #006233;");
            predictionStatusLabel.setVisible(true);
            winnerPredictionCombo.setDisable(true);
        } catch (Exception e) {
            predictionStatusLabel.setText("Erreur lors de l'enregistrement.");
            predictionStatusLabel.setStyle("-fx-text-fill: red;");
            predictionStatusLabel.setVisible(true);
            e.printStackTrace();
        }
    }

    private void loadMatchesPreview() {
        matchesPreviewContainer.getChildren().clear();

        try {
            List<Match> matches = matchDao.findAll();
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMM • HH:mm");

            int count = 0;
            for (Match match : matches) {
                if (count >= 3)
                    break;

                VBox card = createVerticalMatchCard(match, sdf);
                matchesPreviewContainer.getChildren().add(card);
                count++;
            }
        } catch (Exception e) {
            Label error = new Label("Impossible de charger les matchs");
            error.setStyle("-fx-text-fill: white;");
            matchesPreviewContainer.getChildren().add(error);
        }
    }

    /**
     * Crée une carte Verticale (Image en haut, Contenu en bas)
     */
    private VBox createVerticalMatchCard(Match match, SimpleDateFormat sdf) {
        VBox cardRoot = new VBox();
        cardRoot.setMinWidth(280);
        cardRoot.setMaxWidth(280);
        cardRoot.setStyle("-fx-background-radius: 15; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0, 0, 4);");

        // 1. Visuel (Haut)
        StackPane imageContainer = new StackPane();
        imageContainer.setPrefHeight(160);
        imageContainer.setStyle(
                "-fx-background-color: linear-gradient(to bottom right, #8A1B20, #0F172A); -fx-background-radius: 15 15 0 0;");

        Label phaseBadge = new Label(match.getMatchPhase());
        phaseBadge.setStyle(
                "-fx-background-color: #C9A227; -fx-text-fill: #0F172A; -fx-font-weight: bold; -fx-padding: 5 10; -fx-background-radius: 4;");
        StackPane.setAlignment(phaseBadge, Pos.TOP_LEFT);
        StackPane.setMargin(phaseBadge, new javafx.geometry.Insets(15));

        // Placeholder Icon/Text if no real image
        Label vsIcon = new Label("VS");
        vsIcon.setStyle("-fx-text-fill: rgba(255,255,255,0.2); -fx-font-size: 60px; -fx-font-weight: 900;");

        imageContainer.getChildren().addAll(vsIcon, phaseBadge);

        // 2. Contenu (Bas) - Fond Vert Sombre/Bleu
        VBox contentBox = new VBox(10);
        contentBox.setAlignment(Pos.CENTER_LEFT);
        contentBox.setPadding(new javafx.geometry.Insets(20));
        contentBox.setStyle("-fx-background-color: #013220; -fx-background-radius: 0 0 15 15;"); // Dark Green

        // Date & Lieu
        HBox dateLocBox = new HBox(8);
        Label dateLabel = new Label(sdf.format(match.getMatchDate()));
        dateLabel.setStyle("-fx-text-fill: #C9A227; -fx-font-weight: bold; -fx-font-size: 13px;");
        Label locLabel = new Label("• " + match.getCity());
        locLabel.setStyle("-fx-text-fill: rgba(255,255,255,0.7); -fx-font-size: 13px;");
        dateLocBox.getChildren().addAll(dateLabel, locLabel);

        // Equipes
        Label teamsLabel = new Label(match.getTeamHome() + "\nvs " + match.getTeamAway());
        teamsLabel.setStyle("-fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: 900; -fx-wrap-text: true;");

        // Bouton Réserver
        Button buyBtn = new Button("Réserver Ticket");
        buyBtn.setMaxWidth(Double.MAX_VALUE);
        buyBtn.getStyleClass().add("btn-mustard-gold");
        buyBtn.setOnAction(e -> navigateToPurchase(match.getId()));

        contentBox.getChildren().addAll(dateLocBox, teamsLabel, new Region(), buyBtn);
        VBox.setVgrow(new Region(), Priority.ALWAYS); // Spacer

        cardRoot.getChildren().addAll(imageContainer, contentBox);
        return cardRoot;
    }

    private void navigateToPurchase(Integer matchId) {
        try {
            PurchaseController.setSelectedMatchId(matchId);
            App.setRoot("views/purchase");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void navigateToMatchDetails(Integer matchId) {
        try {
            MatchDetailsController.setMatchId(matchId);
            App.setRoot("views/match_details");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void showHome() throws IOException {
        App.setRoot("views/home");
    }

    @FXML
    private void showMatches() throws IOException {
        App.setRoot("views/matches");
    }

    @FXML
    private void showMyTickets() throws IOException {
        App.setRoot("views/my-tickets");
    }

    @FXML
    private void showResale() throws IOException {
        App.setRoot("views/resale");
    }

    @FXML
    private void handleLogout() throws IOException {
        SessionManager.getInstance().logout();
        App.setRoot("views/login");
    }
}
