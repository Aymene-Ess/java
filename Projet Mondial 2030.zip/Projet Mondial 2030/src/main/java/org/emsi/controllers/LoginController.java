package org.emsi.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import org.emsi.App;
import org.emsi.dao.UserDao;
import org.emsi.entities.User;
import org.emsi.util.SessionManager;

import java.io.IOException;

/**
 * Contrôleur pour la vue de connexion/inscription
 */
public class LoginController {

    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label errorLabel;
    @FXML
    private VBox registerSection;

    @FXML
    private TextField regUsernameField;
    @FXML
    private TextField regEmailField;
    @FXML
    private PasswordField regPasswordField;
    @FXML
    private Label regErrorLabel;

    private final UserDao userDao = new UserDao();

    @FXML
    public void initialize() {
        errorLabel.setText("");
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Veuillez remplir tous les champs");
            return;
        }

        try {
            // DEBUG LOGGING
            try (java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.FileWriter("login_debug.log", true))) {
                pw.println("Attempting login for: " + username);
            } catch (Exception ignored) {
            }

            User user = userDao.authenticate(username, password);

            if (user != null) {
                // Connexion réussie
                try (java.io.PrintWriter pw = new java.io.PrintWriter(
                        new java.io.FileWriter("login_debug.log", true))) {
                    pw.println("Login success! Role: " + user.getRole());
                } catch (Exception ignored) {
                }

                SessionManager.getInstance().login(user);

                if (user.isAdmin()) {
                    App.setRoot("views/admin_dashboard");
                } else {
                    App.setRoot("views/home");
                }
            } else {
                showError("Nom d'utilisateur ou mot de passe incorrect");
            }
        } catch (Throwable e) {
            String msg = e.getMessage();
            if (msg == null)
                msg = "Erreur inconnue (" + e.getClass().getSimpleName() + ")";

            if (msg.contains("Connection refused") || msg.contains("Access denied")) {
                showError("Erreur de connexion à la base de données");
            } else {
                showError("Erreur: " + msg);
            }
            e.printStackTrace();
            try {
                java.io.PrintWriter pw = new java.io.PrintWriter("login_error.log");
                e.printStackTrace(pw);
                pw.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    @FXML
    private VBox loginForm;
    @FXML
    private VBox loginFooter;

    @FXML
    private void showRegister() {
        loginForm.setVisible(false);
        loginForm.setManaged(false);
        loginFooter.setVisible(false);
        loginFooter.setManaged(false);

        registerSection.setVisible(true);
        registerSection.setManaged(true);
    }

    @FXML
    private void hideRegister() {
        registerSection.setVisible(false);
        registerSection.setManaged(false);
        clearRegisterFields();

        loginForm.setVisible(true);
        loginForm.setManaged(true);
        loginFooter.setVisible(true);
        loginFooter.setManaged(true);
    }

    @FXML
    private void handleRegister() {
        String username = regUsernameField.getText().trim();
        String email = regEmailField.getText().trim();
        String password = regPasswordField.getText();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            showError("Veuillez remplir tous les champs d'inscription");
            return;
        }

        if (username.length() < 3) {
            showError("Le nom d'utilisateur doit contenir au moins 3 caractères");
            return;
        }

        if (password.length() < 4) {
            showError("Le mot de passe doit contenir au moins 4 caractères");
            return;
        }

        if (!email.contains("@")) {
            showError("Veuillez entrer une adresse email valide");
            return;
        }

        try {
            if (userDao.usernameExists(username)) {
                showError("Ce nom d'utilisateur est déjà pris");
                return;
            }

            User newUser = userDao.register(username, password, email);

            if (newUser != null) {
                // Inscription réussie, connexion automatique
                SessionManager.getInstance().login(newUser);
                App.setRoot("views/home");
            }
        } catch (Exception e) {
            showError("Erreur lors de l'inscription");
            e.printStackTrace();
        }
    }

    private void showError(String message) {
        if (registerSection.isVisible()) {
            if (regErrorLabel != null) {
                regErrorLabel.setText(message);
                regErrorLabel.setStyle("-fx-text-fill: #C1272D;");
            }
        } else {
            errorLabel.setText(message);
            errorLabel.setStyle("-fx-text-fill: #C1272D;");
        }
    }

    private void clearRegisterFields() {
        regUsernameField.clear();
        regEmailField.clear();
        regPasswordField.clear();
        if (regErrorLabel != null)
            regErrorLabel.setText("");
        errorLabel.setText("");
    }

    @FXML
    private void showConfirmation() {
        try {
            App.setRoot("views/confirmation");
        } catch (IOException e) {
            e.printStackTrace();
            showError("Erreur lors du chargement de la confirmation: " + e.getMessage());
        }
    }
}
