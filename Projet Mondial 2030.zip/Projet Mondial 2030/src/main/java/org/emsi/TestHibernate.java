package org.emsi;

import org.emsi.dao.HibernateUtil;
import org.hibernate.SessionFactory;

public class TestHibernate {
    public static void main(String[] args) {
        System.out.println("Starting Hibernate Test...");
        try {
            SessionFactory sf = HibernateUtil.getSessionFactory();
            System.out.println("SessionFactory created successfully: " + sf);
            HibernateUtil.shutdown();
        } catch (Throwable e) {
            System.err.println("Hibernate Initialization FAILED:");
            e.printStackTrace();
        }
    }
}
